DROP view IF EXISTS Recharges;
DROP view IF EXISTS Bornes;
DROP TABLE IF EXISTS RechargeBases;
DROP TABLE IF EXISTS Locations;
DROP TABLE IF EXISTS BorneBases;
DROP TABLE IF EXISTS Entreprises;
DROP TABLE IF EXISTS Voitures;
DROP TABLE IF EXISTS TypeBorneBases;


CREATE TABLE TypeBorneBases (
	typeRecharge_typebornebase TEXT NOT NULL,
	puissance_typebornebase REAL NOT NULL,
	prix_typebornebase REAL NOT NULL,
	CONSTRAINT pk_type_c0 PRIMARY KEY (typeRecharge_typebornebase, puissance_typebornebase),
	CONSTRAINT ck_type_c1 CHECK (prix_typebornebase > 0 and puissance_typebornebase > 0)
);

CREATE TABLE Voitures (
	marque_voiture TEXT NOT NULL,
	modele_voiture TEXT NOT NULL,
	couleur_voiture TEXT NOT NULL,
	CONSTRAINT pk_voiture_c0 PRIMARY KEY (marque_voiture, modele_voiture, couleur_voiture)
);

CREATE TABLE Entreprises (
    nom_entreprise TEXT NOT NULL,
    courriel_entreprise TEXT NOT NULL,
    numTel_entreprise TEXT NOT NULL,
    CONSTRAINT pk_entreprise_c0 PRIMARY KEY (nom_entreprise)
);

CREATE TABLE BorneBases (
    numero_bornebase INTEGER NOT NULL,
    nbPlaces_bornebase INTEGER NOT NULL,
    typeRecharge_typebornebase TEXT NOT NULL,
    puissance_typebornebase REAL NOT NULL,
    nom_entreprise TEXT NOT NULL,
    dateInst_bornebase DATE NOT NULL,
    CONSTRAINT pk_borne_c0 PRIMARY KEY (numero_bornebase),
    CONSTRAINT fk_borne_c1 FOREIGN KEY (typeRecharge_typebornebase, puissance_typebornebase)
                REFERENCES TypeBorneBases(typeRecharge_typebornebase, puissance_typebornebase),
    CONSTRAINT fk_borne_c2 FOREIGN KEY (nom_entreprise)
                REFERENCES Entreprises(nom_entreprise)
    CONSTRAINT ck_borne_c3 CHECK (dateInst_bornebase <= 2024)
);


CREATE TABLE Locations (
	ville_location TEXT NOT NULL,
	adresse_location TEXT NOT NULL,
	numero_bornebase INTEGER NOT NULL,
	CONSTRAINT pk_location_c0 PRIMARY KEY (ville_location, adresse_location),
	CONSTRAINT fk_location_c1 FOREIGN KEY (numero_bornebase) 
				REFERENCES BorneBases(numero_bornebase)
);

CREATE TABLE RechargeBases (
    marque_voiture TEXT NOT NULL,
    modele_voiture TEXT NOT NULL,
    numero_bornebase INTEGER NOT NULL,
    CONSTRAINT fk_recharge_c0 primary KEY (marque_voiture, modele_voiture, numero_bornebase)
);

CREATE VIEW Bornes (
    numero_bornebase,
    nbPlaces_bornebase,
    typeRecharge_typebornebase,
    puisssance_typebornebase,
    nom_entreprise,
    dateInst_bornebase,
    prixActuel_borne) AS
        SELECT numero_bornebase,
                nbPlaces_bornebase,
                typeRecharge_typebornebase,
                puissance_typebornebase,
                nom_entreprise,
                dateInst_bornebase,
                -- Calcul du prix actuel: prix initial * (1 + 0.1)^(annee actuelle - annee de mise en service)
                prix_typebornebase * power(1 + 0.1, strftime('%Y', 'now') - dateInst_bornebase) AS prixActuel_borne 
        FROM BorneBases JOIN TypeBorneBases USING (typeRecharge_typebornebase , puissance_typebornebase) ;

 
CREATE VIEW Recharges (
    marque_voiture,
    modele_voiture,
    nbBornes_possible) AS
        SELECT marque_voiture, 
            modele_voiture,  
            Count(numero_bornebase) AS nbBornes_possible
        FROM RechargeBases
        GROUP BY marque_voiture, modele_voiture ;