-- Jeux de données OK (ça doit marcher)

-- Insérer des données dans la table TypeBorneBases
INSERT INTO TypeBorneBases VALUES ('Type 2', 22.0, 1.45);
INSERT INTO TypeBorneBases VALUES ('Domestique', 3.7, 0.24);   -- 19 Boulevard Maréchal Lyautey, 38000 Grenoble 
INSERT INTO TypeBorneBases VALUES ('Combo CSS', 25.0, 1.45);  -- Rue Marceau, 38000 Grenoble  
INSERT INTO TypeBorneBases VALUES ('Chademo', 25.0, 1.45);
INSERT INTO TypeBorneBases VALUES ('Type 2', 22.1, 0.24);


-- Insérer des données dans la table Voitures
INSERT INTO Voitures VALUES ('Tesla', 'Model S', 'Noir');   -- combo css, type 2, 
INSERT INTO Voitures VALUES ('Tesla', 'Model S', 'Blanc');  -- combo css, type 2
INSERT INTO Voitures VALUES ('Renault', 'Zoe', 'Blanc');    -- type 2, combo css
INSERT INTO Voitures VALUES  ('BMW', 'i3', 'Gris');         --type 2, combo css
INSERT INTO Voitures VALUES  ('Nissan', 'Leaf', 'Bleu');


-- Insérer des données dans la table Entreprises
INSERT INTO Entreprises VALUES ('Bouygues', 'contactbouygues@bouy.fr', '0413645421');
INSERT INTO Entreprises VALUES ('SEDI', 'sedicontact@sedi.fr', '0476223978');
INSERT INTO Entreprises VALUES ('Driveco', 'drivecocontact@driveco.fr', '0972562680');
INSERT INTO Entreprises VALUES ('EDF', 'edfcontact@edf.fr', '0972675038');

-- Insérer des données dans la table BorneBases
INSERT INTO BorneBases VALUES (1, 2, 'Type 2',22.0, 'Bouygues', '2015');
INSERT INTO BorneBases VALUES (2, 1, 'Domestique',3.7, 'SEDI', '2014');
INSERT INTO BorneBases VALUES (3, 3, 'Combo CSS',25.0, 'EDF', '2015');
INSERT INTO BorneBases VALUES (4, 3, 'Chademo',25.0, 'Driveco', '2020');
INSERT INTO BorneBases VALUES (5, 3, 'Type 2',22.1, 'Driveco', '2019');

-- Insérer des données dans la table Locations
INSERT INTO Locations VALUES ('Grenoble', 'Rue Jacquard', 1);
INSERT INTO Locations VALUES ('Grenoble', '19 Boulevard Marechal Lyautey', 2);
INSERT INTO Locations VALUES ('Grenoble', 'Rue Marceau', 3);
INSERT INTO Locations VALUES ('Grenoble', 'Cours De La Liberation', 4);
INSERT INTO Locations VALUES ('Meylan', '1B Boulevard des Alpes', 5);

-- Insérer des données dans la table RechargeBases
INSERT INTO RechargeBases VALUES ('Tesla', 'Model S', 1);
INSERT INTo RechargeBases VALUES ('Tesla', 'Model S', 3);
INSERT INTO RechargeBases VALUES ('Renault', 'Zoe', 1);
INSERT INTO RechargeBases VALUES ('BMW', 'i3', 3);
INSERT INTO RechargeBases VALUES ('Nissan', 'Leaf', 4);
INSERT INTO RechargeBases VALUES ('Nissan', 'Leaf', 5);
