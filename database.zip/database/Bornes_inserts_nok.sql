-- Jeux de données NOK (ne doit pas marcher àprès avoir éxécuté le jeux de données NOK)

-- Erreur : puissance/prix négative,nulle
INSERT INTO TypeBorneBases VALUES ('Type 2', -22.0, 1.45);
INSERT INTO TypeBorneBases VALUES ('Domestique', 0, 0.24);
INSERT INTO TypeBorneBases VALUES ('Combo CSS', 25.0, -1.45);
INSERT INTO TypeBorneBases VALUES ('Chademo', 25.0, 0);

-- Erreur: date d'installation future
INSERT INTO BorneBases VALUES (6, 3, 'Type 2',22.0, 'Bouygues', '2026');

-- Erreur: entreprise existant
INSERT INTO Entreprises VALUES ('Bouygues', 'blablabla@gmail.fr', '0413645421');

-- Erreur: bornebase existant
INSERT INTO BorneBases VALUES (1, 2, 'Type 2',23.0, 'Bouygues', '2015');

-- Erreur: bornebase avec typeRecharge inconnu
INSERT INTO BorneBases VALUES (7, 3, 'Type 3',22.0, 'Bouygues', '2015');

-- Erreur: 2 bornes dans le même emplacement
INSERT INTO Locations VALUES ('Grenoble', 'Rue Jacquard', 6);

-- Erreur: voiture inconnu
INSERT INTO RechargeBases VALUES ('Renault', 'Zoe', 6);
